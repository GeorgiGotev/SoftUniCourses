export default class Settings {
    constructor(){
        this.destructablesMinSize = 40;
        this.destructablesMaxSize = 100;
        this.width = 800;
        this.height = 480;
        this.spawnInterval = 2000;
    }
}