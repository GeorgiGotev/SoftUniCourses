class SmartHike {

}