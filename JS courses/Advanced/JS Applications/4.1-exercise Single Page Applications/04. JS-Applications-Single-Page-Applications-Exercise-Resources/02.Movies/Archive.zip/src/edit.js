import { showView } from './util.js';

const editSection = document.querySelector('#edit-movie');

export function editPage() {
    showView(editSection);
}


