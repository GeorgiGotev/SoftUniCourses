import { showHome } from "./home.js";
// import { showDetails } from "./details.js";

document.getElementById('homeLink').addEventListener('click', showHome);
document.querySelector('.topic-title')

showHome();