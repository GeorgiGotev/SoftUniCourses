import { deleteById, getById } from '../api/data.js';
import { html } from '../lib.js';
import { getUserData } from '../util.js';

const detailsTemplate = (product, isOwner, onDelete) => html`  <section id="meme-details">
<h1>Meme Title: ${product.title}

</h1>
<div class="meme-details">
    <div class="meme-img">
        <img alt="meme-alt" src=${product.imageUrl}>
    </div>
    <div class="meme-description">
        <h2>Meme Description</h2>
        <p>
            ${product.description}
        </p>

        <!-- Buttons Edit/Delete should be displayed only for creator of this meme  -->
        ${isOwner? html`<a class="button warning" href="/edit/${product._id}">Edit</a>
        <button id="delete-btn" @click=${onDelete} href="javascript:void(0)" class="button danger">Delete</button>`:null}
        
    </div>
</div>
</section>`;

export async function detailsView(ctx) {
    const id = ctx.params.id;
    const product = await getById(id);
    const user=getUserData();
    let isOwner=null;
    if(user){
        isOwner = ctx.user._id == product._ownerId;
    }

    ctx.render(detailsTemplate(product, isOwner, onDelete));

    async function onDelete() {
        const choice = confirm('Are you sure?');

        if (choice) {
            await deleteById(id);

            ctx.page.redirect('/catalog');
        }
    }
}





// import { deleteById, getById, isLiked, like, likeNum } from '../api/data.js';
// import { html } from '../lib.js';
// import { getUserData } from '../util.js';

// const detailsTemplate = (isClicked,user, product, isOwner,number,onLike, onDelete) => html`<section id="details">
// <div id="details-wrapper">
//   <p id="details-title">Album Details</p>
//   <div id="img-wrapper">
//     <img src=${product.imageUrl} alt="example1" />
//   </div>
//   <div id="info-wrapper">
//     <p><strong>Band:</strong><span id="details-singer">${product.singer}</span></p>
//     <p>
//       <strong>Album name:</strong><span id="details-album">${product.album}</span>
//     </p>
//     <p><strong>Release date:</strong><span id="details-release">${product.release}</span></p>
//     <p><strong>Label:</strong><span id="details-label">${product.label}</span></p>
//     <p><strong>Sales:</strong><span id="details-sales">${product.sales}</span></p>
//   </div>
//   <div id="likes">Likes: <span id="likes-count">${number}</span></div>
//   <div id="action-buttons">
  
//   <!--Edit and Delete are only for creator-->
//   ${isOwner
//         ? html`<a href=${`/edit/${product._id}`} id="edit-btn">Edit</a>
//             <a @click=${onDelete} href="javascript:void(0)" id="delete-btn">Delete</a> `
//         : html`<a style="visibility:hidden;" href=${`/edit/${product._id}`} id="edit-btn">Edit</a>
//             <a style="visibility:hidden;" @click=${onDelete} href="javascript:void(0)" id="delete-btn">Delete</a>`}
//   ${user && !isOwner && !isClicked  ?
//     html`<a @click=${onLike} href="javascript:void(0)" id="like-btn">Like</a>`: null
//   }
            
//   </div>
// </div>
// </section>`;



// export async function detailsView(ctx) {
    
//     const id = ctx.params.id;
//     let isClicked=null; 
//     const user= await getUserData();
//     const product = await getById(id);
//     const isOwner =user  && ctx.user._id == product._ownerId;
//     const number= await likeNum(id);
//     if(user){
//       isClicked= await isLiked(product._id, user._id)
//     }

//     ctx.render(detailsTemplate(isClicked,user, product, isOwner,number,onLike, onDelete));

    


//     async function onDelete() {
//         const choice = confirm('Are you sure?');

//         if (choice) {
//             await deleteById(id);

//             ctx.page.redirect('/catalog');
//         }
//     }

//     async function onLike() {
//       await like({ albumId:id });
//       document.getElementById('like-btn').style.display = 'none';
//       ctx.page.redirect('/catalog/' + id);
//     }
// }






