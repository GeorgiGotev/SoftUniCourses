let names = ['Pesho', 'Gosho', 'Stamat', 'Mariya', 'Kalinka', 'Vladi', 'Gaby'];

// Using for loop
for (let i = 0; i < names.length; i++) {
    console.log(`Hello! My name is ${names[i]}`);
}
