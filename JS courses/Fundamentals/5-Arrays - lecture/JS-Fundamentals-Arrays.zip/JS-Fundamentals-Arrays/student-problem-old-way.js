let student1 = 'Pesho';
let student2 = 'Gosho';
let student3 = 'Stamat';
let student4 = 'Mariyka';
//... to student24

// Problem: each student need to say Hello, my name is ${name}
console.log(`Hello my name is ${student1}.`);
console.log(`Hello my name is ${student2}.`);
console.log(`Hello my name is ${student3}.`);
console.log(`Hello my name is ${student4}.`);
// ...

