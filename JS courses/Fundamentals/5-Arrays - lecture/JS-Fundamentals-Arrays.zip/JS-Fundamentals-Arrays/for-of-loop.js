let names = ['Pesho', 'Gosho', 'Stamat', 'Mariyka', 'Kalinka'];

for (let name of names) {
    console.log(`Hello! My name is ${name}`);
}

