let cars = ['bmw', 'mercedess', 'toyota', 'vw'];

// Add element at the begining of the array
cars.unshift('lada');
console.log(cars);

// Remove the first element in the array
let firstCar = cars.shift();
console.log(cars);
console.log(firstCar);
