// declare variable
let number = 10;
console.log(number);
number = 20;
console.log(number);

// declare constant
const sum = (a, b) => a + b;
console.log(sum(10,20));
