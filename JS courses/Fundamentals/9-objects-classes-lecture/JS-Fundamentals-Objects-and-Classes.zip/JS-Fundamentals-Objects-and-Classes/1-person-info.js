function printInfo(firstName, lastName, age) {
    let info = {
        firstName: firstName,
        lastName: lastName,
        age: age,
    }

    return info;
}

printInfo("Peter", 
"Pan",
"20"
);
