let info = {
    firstName: 'Pesho',
    lastName: 'Petrov',
    age: 28,
    eyeColor: 'brown',
    isMale: true,
};

let objectProperties = Object.keys(info);
let objectValues = Object.values(info);
let objectEntries = Object.entries(info);
console.log(objectEntries);
